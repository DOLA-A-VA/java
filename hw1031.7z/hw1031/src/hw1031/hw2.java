package hw1031;
import java.util.*;
public class hw2 {

	public static void main(String[] args) {
		int L = rInt();
		int n = rInt();
		D3( L , n );
	}
    static void D3( int m , int n){
    	for ( int i = 0 ; i < m ; i++ ){
    		for ( int k = 0 ; k < n ; k++ ){
    			//print space
    			for ( int j = 0 ; j < i ; j++ )
    				SOP(" ");
    	   		//print *
    			for ( int j = 0 ; j < 2*(m-i)-1 ; j++ )
    				SOP("*");
    	   		//print space
    			for ( int j = 0 ; j < i ; j++ )
    				SOP(" ");
    			}
    	   	SOP("\n");		
    	}
    } 
	static int rInt(){
    	Scanner sc = new Scanner( System.in );
    	return sc.nextInt();
    }
    static void SOP( String s ){
    	System.out.print( s );
    }
}
